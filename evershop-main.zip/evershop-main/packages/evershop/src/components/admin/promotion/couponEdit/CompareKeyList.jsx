export const compareKeyList = [
  {
    key: 'category',
    label: 'Category'
  },
  {
    key: 'collection',
    label: 'Collection'
  },
  {
    key: 'attribute_group',
    label: 'Attribute Group'
  },
  {
    key: 'sku',
    label: 'Sku'
  },
  {
    key: 'price',
    label: 'Price'
  }
];
